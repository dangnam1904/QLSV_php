<?php require "header.php"; ?>
<div class="group-box">
	<div align="center">
	<div class="title">Thông báo</div>
	
	 <h3>Chào mừng bạn đến với Hệ thống quản lý đào tạo.</h3> 
	 
	 Các chức năng đang được cập nhật, xin vui lòng quay lại sau. 
	 <p>
	 </div>
</div>




	
</div>
<?php require "footer.php";